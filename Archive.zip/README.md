# Assignment3
To run:

jar -jar runnable.jar